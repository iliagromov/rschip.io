let header = 'header component works';
console.log(header);

// Класс для животных
// const animal = {
//     weight: 10,
//     showWeight: function(){
//         console.log(this.weight);
//     },
//     showWeight2: function(){
//         setTimeout(function(){
//             console.log(this.weight);
//             // чем является this?
//             console.log(this);
//         }, 1000)
//     },
//     // 
//     showWeight3: function(){
//         setTimeout(()=>{
//             console.log(this.weight);
//         }, 1000)
//     }
// }

// // наследую класс животного
// let cat = animal;
// // добавляю вес для данного животного
// cat.weight = 20;

// cat.showWeight()
// cat.showWeight2()
// cat.showWeight3()
